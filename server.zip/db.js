const mysql = require('mysql')

let connection = mysql.createConnection({
    host: 'vh320.timeweb.ru',
    port: '3306',
    user: 'cp86555',
    password: '9aDhXuF3',
    database: 'cp86555_konkurs'
})

connection.connect((error) => {
    if (error) {
        return console.log(error)
    } else {
        return console.log('Подключение к БД успешно!')
    }
})

module.exports = connection